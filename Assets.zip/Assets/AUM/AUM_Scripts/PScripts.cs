﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PScripts : MonoBehaviour
{
    public int playerNumber;

    public SpriteRenderer sr;

    public Movement movement;

    public Animator shieldPongBonusAnimator;
}
