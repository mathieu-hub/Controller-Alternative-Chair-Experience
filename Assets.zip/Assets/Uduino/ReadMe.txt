﻿Thanks for purchasing Uduino.

You can find more informations and tutorials on Uduino's webpage : 
http://marcteyssier.com/uduino/

You are stuck? Ask on the forum:
http://marcteyssier.com/uduino/forum/

IMPORTANT: 
If you are Upgrading from Uduino 2.x to Uduino 3.x, please delete the /Uduino/ before importing the new one. 